requirejs.config({
	paths: {
		zepto: '../base/zepto'
	},
	shim: {
		'zepto': {
			exports: '$'
		}
	}
});
define(["../piece/js/components/toast.js", "../base/util.js", "../base/openapi.js", "../base/loader.js"], function(Toast, Util, OpenAPI, Loader) {

	var ajaxloader = new Loader({
		autoshow: false,
		target: 'body',
		text: "加载中...",
	});

	// var idcard = window.localStorage.getItem("username");
	// console.log("idcard ifi = " + idcard);
	// if (typeof idcard !== "undefined" && idcard !== null && idcard !== "") {
	// 	getUesrInfo(idcard);
	// }

	function getUesrInfo(idcard) {

		var params = {
			"state": "getInfosPortal",
			"serviceType": "getEmployeeInfo",
			"idCard": idcard
		};
		$.ajax({
			url: OpenAPI.baseApi + "getEmployeeInfo",
			// type: "GET",
			data: params,
			"dataType": "json",
			contentType: "application/json",
			success: function(data, textStatus, jqXHR) {
				var personInfoData = JSON.stringify(data);
				console.log("perlk " + personInfoData);

				console.log("tele = " + data.resultForm.tele);
				var myMobile = data.resultForm.tele;
				var uid = data.resultForm.idcard;
				window.localStorage.setItem("myMobile", myMobile);
				window.localStorage.setItem("username", uid);


				var mobile = window.localStorage.getItem("myMobile");
				var cid = window.localStorage.getItem("username");

				//身份证号码
				var cardId = $(".cardId").val();
				//手机号码
				var phoneId = $(".phoneId").val();

				//身份证号匹配
				if (cardId == cid) {
					if (phoneId !== mobile) {
						Toast("手机号不匹配");
						return;
					}
				}
				//手机号匹配
				if (phoneId == mobile) {
					if (cardId !== cid) {
						Toast("手机号和身份证号不匹配");
						return;
					}

				}
				if (mobile !== null && mobile !== "") {
					request(cardId, phoneId);
				}
			}
		});
	};

	// 删除输入框逻辑
	$(".cardId")[0].addEventListener("input", function() {
		var cardId = $(".cardId")[0].value;
		if (cardId.length > 0) {
			$(this).next(".inputDel").show();
		} else {
			$(this).next(".inputDel").hide();
		}
	}, false);
	$(".phoneId")[0].addEventListener("input", function() {
		var phoneId = $(".phoneId")[0].value;
		if (phoneId.length > 0) {
			$(this).next(".inputDel").show();
		} else {
			$(this).next(".inputDel").hide();
		}
	}, false);
	$(".inputDel").click(function(e) {
		var $input = $(e.target).prev(),
			className = $input.attr("class");
		console.log(className);
		console.log($input.val());
		$(this).hide();
		$input.val("");
		$("." + className).focus();
	});

	$(".backButton").click(function() {
		window.history.back();
	});
	var uid = window.localStorage.getItem("username");
	if (!Util.isNull(uid)) {
		$(".cardId")[0].value = uid;
	}
	$(".submitbtn").click(function() {
		//身份证号码
		var cardId = $(".cardId").val();
		//手机号码
		var phoneId = $(".phoneId").val();
		console.log("phoneId = " + phoneId);
		//手机号码正则表达式
		var reTel = /^0?(13[0-9]|15[012356789]|18[0-9]|14[57])[0-9]{8}$/;
		var reId = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X)$)/;
		if (!reId.test(cardId)) {
			Toast('请输入正确的身份证号');
			return;
		} else if (!reTel.test(phoneId)) {
			Toast('请输入正确的手机号码');
			return;
		} else {
			getUesrInfo(cardId);
		}

	});

	function request(cardId, phoneId) {
		$.ajax({
			url: OpenAPI.resetUrl,
			type: "POST",
			data: {
				"uid": cardId,
				"telephoneNumber": phoneId
			},
			beforeSend: function(error) {
				// 显示loader框
				ajaxloader.show();
			},
			error: function(error) {
				Toast("接口数据可能有错哦");

				console.log("日志正在记录.................");
				console.log(error);
				// 错误日志记录
				Util.recordlog(error);
				console.log("日志已记录....................");
			},
			success: function(data) {
				console.log("获得密码成功方法调用: " + JSON.stringify(data));
				console.log("data.errorMessage = " + JSON.stringify(data));

				if (data.errorMessage) {
					if ("Uid does not exist." == data.errorMessage) {
						Toast("账号不存在");
					}
					if ("Telephone number do not match." == data.errorMessage) {
						Toast("手机号不匹配");
					}

				} else {

					window.location.href = "../com.midea.login/index.html";
				}
			},
			complete: function() {
				ajaxloader.hide();
			}
		});
	}
});