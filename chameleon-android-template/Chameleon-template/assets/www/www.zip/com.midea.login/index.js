requirejs.config({
	paths: {
		zepto: '../base/zepto'
	},
	shim: {
		'zepto': {
			exports: '$'
		}
	}
});
define(["../piece/js/components/toast.js", "../base/util.js", "../base/openapi.js", "../base/loader.js"], function(Toast, Util, OpenAPI, Loader) {
	console.log("require");
	var ajaxloader = new Loader({
		autoshow: false,
		target: 'body',
		text: "加载中...",
	});
	var deviceId;
	var appKey;
	var appId;
	cordova.exec(function(data) {
		var appInfo = JSON.parse(data);
		deviceId = appInfo.deviceId;
		appKey = appInfo.appKey;
		appId = appInfo.appId;
	}, function(error) {}, "CubeSettingPlugin", "getAppInfo", []);

	// 全局变量
	var selImg = "img/remPass.ing";
	var unSelImg = "img/remPassNo.ing";
	var reg = /^\d*$/;
	//初始化显示密码
	function initPass() {
		var rdVal = window.localStorage.getItem("remPass");
		var uid = window.localStorage.getItem("username");
		console.info("uid = " + uid);
		if (typeof uid !== "undefined" && uid !== null && uid !== "") {
			$(".identityId")[0].value = uid;
		}
		if (Util.isNull(rdVal)) {
			return false;
		}
		if (rdVal === "checked") {
			$(".passimg")[0].src = selImg;
			$("#remPass").attr("data-value", "checked");

			fulfPass();
			//填充账号密码
		} else if (rdVal === "uncheck") {
			$(".passimg")[0].src = unSelImg;
			$("#remPass").attr("data-value", "uncheck");

		}
	}

	function fulfPass() {
		var logininfo = window.localStorage.getItem("logininfo");
		console.log("logininfo = " + logininfo);
		if (typeof logininfo !== "undefined" && logininfo !== null && logininfo !== "" && logininfo !== " ") { //!Util.isNull(logininfo)
			var newinfo = JSON.parse(logininfo);
			console.log("newinfo = " + JSON.stringify(newinfo));
			if (newinfo !== null) {
				$(".identityId")[0].value = newinfo.username;
				$(".password")[0].value = newinfo.password;
				$(".inputDel").show();
			}

		}
		var uid = window.localStorage.getItem("username");
		console.info("uid = " + uid);
		if (typeof uid !== "undefined" && uid !== null && uid !== "") {
			$(".identityId")[0].value = uid;
		}

	}

	//初始化显示密码
	initPass();

	$(".submitbtn").click(function() {
		// 验证信息
		var data = checkLogin();
		console.log("lanjianlong:  appKey = " + appKey);

		// var param = {
		// 	"username": data.username,
		// 	"password": data.password,
		// 	"appId": "com.midea.mmp2",
		// 	"appKey": "a970c6239ee5f5d6bc142fe4696a95a3", //0671d8943ba2598527cbcfb78bce7d23
		// 	"deviceId": "00000000-5e2c-97f7-9f2a-4c670033c587"
		// };

		var param = {
			"username": data.username,
			"password": data.password,
			"appId": appId,
			"appKey": appKey,
			"deviceId": deviceId
		};

		if (data.check) {
			window.localStorage.setItem("logininfo", JSON.stringify(param));
			var url = OpenAPI.loginUrl;
			request(param, url);
		}
	});
	// 记住密码
	$("#remPass").click(function() {
		toggleSel();
	});

	function toggleSel() {
		//alert($("#rememberPassword")[0].src);
		var rdVal = window.localStorage.getItem("remPass");
		if (rdVal === null) {
			rdVal = "uncheck";
		}
		//	var rdVal = $("#remPass").attr("data-value");
		if (rdVal === "uncheck") {
			$(".passimg")[0].src = selImg;
			$("#remPass").attr("data-value", "checked");
			window.localStorage.setItem("remPass", "checked");
		} else if (rdVal === "checked") {
			$(".passimg")[0].src = unSelImg;
			$("#remPass").attr("data-value", "uncheck");
			window.localStorage.setItem("remPass", "uncheck");
		}
	}

	// 验证输入信息
	$(".password").keyup(function() {
		var password = $(".password")[0].value;
		if (password.length > 0) {
			$(this).next(".inputDel").show();
		} else {
			$(this).next(".inputDel").hide();
		}
		if (!reg.test(password)) {
			Toast("密码只能为数字");
			$(".password")[0].value = "";
			$(this).next(".inputDel").hide();
		}
	});
	// 删除输入框逻辑
	$(".identityId")[0].addEventListener("input", function() {
		var identityId = $(".identityId")[0].value;
		if (identityId.length > 0) {
			$(this).next(".inputDel").show();
		} else {
			$(this).next(".inputDel").hide();
		}
	}, false);
	$(".password")[0].addEventListener("input", function() {
		var password = $(".password")[0].value;
		if (password.length > 0) {
			$(this).next(".inputDel").show();
		} else {
			$(this).next(".inputDel").hide();
		}
	}, false);

	//删除输入信息按钮
	$(".inputDel").click(function(e) {
		var $input = $(e.target).prev(),
			className = $input.attr("class");
		console.log(className);
		console.log($input.val());
		$(this).hide();
		$input.val("");
		$("." + className).focus();
	});
	// 信息验证
	function checkLogin() {
		var username, password, data;
		//Toast("hello world");
		username = $(".identityId")[0].value;
		password = $(".password")[0].value;
		data = {
			"username": username,
			"password": password,
			"check": true
		};
		//身份证号正则表达式
		var reId = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X)$)/;
		// 判空
		if (Util.isNull(username)) {
			data.check = false;
			Toast("请输入账号");
		} else if (username.length !== 15 && username.length !== 18) {
			data.check = false;
			Toast("账号不是15位或者18位");
		} else if (username.indexOf("x") == 17) {
			data.check = false;
			Toast('请注意X是大写');
		} else if (!reId.test(username)) {
			Toast('请输入正确的身份证号');
			data.check = false;
		} else if (Util.isNull(password)) {
			data.check = false;
			Toast("请输入密码");
		}
		console.log(data);
		return data;
	}

	function request(param, url) {

		console.log("param:" + param);
		console.log("url:" + url);

		window.localStorage.setItem("username", param.username);
		window.localStorage.setItem("password", param.password);
		$.ajax({
			url: url,
			type: "POST",
			data: param,
			beforeSend: function(error) {
				// 显示loader框
				ajaxloader.show();
			},
			error: function(error) {
				Toast("登陆失败,请重试");
				console.log(error);
				Util.recordlog(error);
			},
			success: function(data) {
				console.log(typeof data);
				console.log(data.uid);
				var reg = /[a-zA-Z]/;
				var userInfo = JSON.parse(data.userInfo);
				console.log("logindata :　" + JSON.stringify(data));
				if (userInfo.uid) {
					//保存用户名和密码到本地
					var mima = param.username.slice(-6);
					var mima1 = param.username.slice(-7, -1);
					if (mima == param.password) {
						window.location.href = "../com.midea.resetPass/index.html";
						// 如果密码中有字母说明第一次登陆
					} else if (reg.test(mima)) {
						if (mima1 == param.password) {
							window.location.href = "../com.midea.resetPass/index.html";
						} else {
							window.location.href = "../com.midea.tools/index.html";
						}
					} else {
						window.location.href = "../com.midea.tools/index.html";
					}


				} else {
					console.info(data);
					Toast("用户名或密码错误");
				}
			},
			complete: function() {
				ajaxloader.hide();
			}
		});
	}
	// 获取窗口高度

	var windowHeight = $(window).height();
	$("body").height(windowHeight);
	$("body").css("background-size", "100% " + windowHeight + "px");
	window.localStorage.setItem("windowHeight", windowHeight);
});