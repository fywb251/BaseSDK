requirejs.config({
	paths: {
		zepto: '../base/zepto'
	},
	shim: {
		'zepto': {
			exports: '$'
		}
	}
});
define(["../piece/js/components/toast.js", "../base/util.js", "../base/openapi.js", "../base/loader.js"], function(Toast, Util, OpenAPI, Loader) {
	$(".backButton").click(function() {
		window.history.back();
	});
	var loader = new Loader({
		autoshow: false,
		target: 'body',
	});
	var regnum = /^\d*$/;
	$("#newpw").keyup(function() {
		var password = $("#newpw")[0].value;
		if (!regnum.test(password)) {
			Toast("密码只能为数字");
			$("#newpw")[0].value = "";
			$(this).next("img").hide();
		}
	});
	$("#repw").keyup(function() {
		var password = $("#repw")[0].value;
		if (!regnum.test(password)) {
			Toast("密码只能为数字");
			$("#repw")[0].value = "";
			$(this).next("img").hide();
		}
	});
	// 删除输入框逻辑
	$(".password")[0].addEventListener("input", function() {
		var password = $(".password")[0].value;
		if (password.length > 0) {
			$(this).next(".inputDel").show();
		} else {
			$(this).next(".inputDel").hide();
		}
	}, false);
	$(".newPass")[0].addEventListener("input", function() {
		var newPass = $(".newPass")[0].value;
		if (newPass.length > 0) {
			$(this).next(".inputDel").show();
		} else {
			$(this).next(".inputDel").hide();
		}
	}, false);
	$(".passagain")[0].addEventListener("input", function() {
		var passagain = $(".passagain")[0].value;
		if (passagain.length > 0) {
			$(this).next(".inputDel").show();
		} else {
			$(this).next(".inputDel").hide();
		}
	}, false);
	$(".inputDel").click(function(e) {
		var $input = $(e.target).prev(),
			className = $input.attr("class");
		console.log(className);
		console.log($input.val());
		$(this).hide();
		$input.val("");
		$("." + className).focus();
	});

	$(".submitbtn").click(function() {
		var oripw = $("#oripw")[0].value;
		var newpw = $("#newpw")[0].value;
		var repw = $("#repw")[0].value;
		var uid = window.localStorage.getItem("username");
		if (uid.indexOf("X") > 0 || uid.indexOf("x") > 0 ) {
			var olpw = uid.substring(uid.length-7, uid.length-1);
			if(newpw === olpw){
				Toast("不能设为初始密码!!");
				return;
			}
		}else{
			var olpw = uid.substring(uid.length-6, uid.length);
			if(newpw === olpw){
				Toast("不能设为初始密码!!");
				return;
			}
		}

		var reg = /^\d{6,}$/;
		if (typeof oripw == "undefined" || oripw == null || oripw == "") {
			Toast("请先验证旧密码!!");
			return;
		}
		if (!reg.test(newpw)) {
			Toast("密码错误,最少6位数字");
			$("#newpw")[0].value = "";
			$("#repw")[0].value = "";
			$(".passagain").next("img").hide();
			$(".newPass").next("img").hide();
			return;
		}
		if (oripw == newpw) {
			Toast("新密码不能和旧密码相同!!");
			$("#newpw")[0].value = "";
			$("#repw")[0].value = "";
			$(".passagain").next("img").hide();
			$(".newPass").next("img").hide();
			return;
		}
		if (newpw == repw) {
			//本地验证密码正确否
			var passw = window.localStorage.getItem("password");
			var uid = window.localStorage.getItem("username");
			console.info("resetPass, uid = " + uid + ": passw = " + passw);
			if (oripw == passw) {
				var options = {
					"uid": uid,
					"password": passw,
					"newPassword": newpw
				};

				$.ajax({
					url: OpenAPI.passRset,
					type: "POST",
					data: options,
					beforeSend: function(error) {
						loader.show();
					},
					// dataType: "json",
					success: function(data) {
						console.info("修改密码成功, data = " + data);
						Toast("修改密码成功，即将跳转到");
						var uid = window.localStorage.getItem("username");
						var count = window.localStorage.getItem("count");
						var saveTime = window.localStorage.getItem("time");
						var agreement = window.localStorage.getItem("agreement");
						var mday = window.localStorage.getItem("mday");
						console.log("agreement = " + agreement);

						window.localStorage.clear();
						window.sessionStorage.clear();
						window.localStorage.setItem("username", uid);
						window.localStorage.setItem("count", count);
						window.localStorage.setItem("time", saveTime);
						window.localStorage.setItem("agreement", agreement);
						window.localStorage.setItem("mday", mday);
						window.location.href = "../com.midea.login/index.html";
					},
					error: function(error) {
						console.log("日志正在记录.................");
						console.log(error);
						// 错误日志记录
						Util.recordlog(error);
						console.log("日志已记录....................");

						Toast("修改密码失败");
					},
					complete: function() {
						loader.hide();
					}
				});
			} else {
				Toast("旧密码不正确!!!");
			}

		} else {
			Toast("两次输入的密码不一致");
		}

	});
});