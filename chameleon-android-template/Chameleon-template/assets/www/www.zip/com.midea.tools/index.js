requirejs.config({
	paths: {
		zepto: '../base/zepto'
	},
	shim: {
		'zepto': {
			exports: '$'
		}
	}
});
define(["../piece/js/components/toast.js", "../base/util.js", "../base/openapi.js", "../base/loader.js"], function(Toast, Util, OpenAPI, Loader) {
	var ajaxloader = new Loader({
		autoshow: false,
		target: 'body',
		text: "加载中...",
	}),
		// 全局变量
		selImg = "img/remPass.ing",
		unSelImg = "img/remPassNo.ing",
		baseData;

	var cacheData = window.sessionStorage.getItem("baseData");
	baseData = JSON.parse(cacheData);
	// 模块跳转
	$(".menuList").on("click", "div", function() {
		targetValue = $(this).attr("data-value");
		if (targetValue == "com.midea.guide/index.html#com.midea.guide/guide") {
			Toast("模块建设中");
			return;
		}
		console.log("aaa , targetValue = " + targetValue);
		if (targetValue == "com.midea.checkIn/index.html") {
			Toast("模块建设中");
			return;
		}
		if (targetValue) {
			window.location.href = "../" + targetValue;
		}
	});
	$(".moreList").on("click", "li", function() {
		targetValue = $(this).attr("data-value");
		if (targetValue === "com.midea.login/index.html") {
			var count = window.localStorage.getItem("count");
			var saveTime = window.localStorage.getItem("time");
			var agreement = window.localStorage.getItem("agreement");
			var mday = window.localStorage.getItem("mday");

			window.localStorage.clear();
			window.sessionStorage.clear();
			window.localStorage.setItem("count", count);
			window.localStorage.setItem("time", saveTime);
			window.localStorage.setItem("agreement", agreement);
			window.localStorage.setItem("mday", mday);
		}
		window.location.href = "../" + targetValue;
	});

	//初始化显示同意协议
	function initagreement() {
		$(".agreement").attr("data-value", "false");
		$(".dealDialog").show();
		$(".masklayer").show();
	}
	// 同意协议
	$(".agreement").click(function() {
		togglepic();
	});

	function togglepic() {
		var agree = $(".agreement").attr("data-value");
		if (agree === "true") {
			$(".agreepic")[0].src = unSelImg;
			$(".agreement").attr("data-value", "false");
			$(".confirmBtn").addClass("greyf");
		} else if (agree === "false") {
			$(".agreepic")[0].src = selImg;
			$(".agreement").attr("data-value", "true");
			$(".confirmBtn").removeClass("greyf");
		}
	}
	// 点击确定按钮
	$(".confirmBtn").click(function() {
		var iftrue = $(".agreement").attr("data-value");
		if (iftrue === "true") {
			// 发送协议确认确认
			legalLogService();
			$(".dealDialog").hide();
			$(".masklayer").hide();
		} else {
			return;
		}
	});
	// 点击取消按钮
	$(".canBtn").click(function() {
		$(".dealDialog").hide();
		$(".masklayer").hide();
		window.location.href = "../com.midea.login/index.html";
	});
	// 个人设置显示
	$(".setting").on("click", function() {
		$(".moreList,.masker").show();
	});
	$(".masker").on("click", function() {
		$(".moreList,.masker").hide();
	});
	// 请求数据
	var logininfo = window.localStorage.getItem("logininfo");
	var url = OpenAPI.baseApi + "getEmployeeInfo";
	console.log(url);
	var loginfo = JSON.parse(logininfo);
	console.log(loginfo);
	//如果缓存没有数据则请求接口
	if (Util.isNull(cacheData)) {
		request();
	} else {
		var renderData = baseData;
		renderTemp(renderData);
		// cacheData
	}

	function renderTemp(data) {
		$(".code").text(data.resultForm.code);
		$(".orgName").text(data.resultForm.unitShortName);
		$(".pername").text(data.resultForm.name);

	}

	function request() {
		var reBack = false;
		var options = {
			"state": "getInfosPortal",
			"serviceType": "getEmployeeInfo",
			"idCard": loginfo.username,
		};
		$.ajax({
			url: url,
			data: options,
			dataType: "json",
			beforeSend: function(error) {
				// 显示loader框
				ajaxloader.show();
			},
			error: function(error) {
				Util.recordlog(error);
				Toast("信息获取失败");
				reBack = true;
			},
			success: function(data) {
				if (!Util.isNull(data)) {
					baseData = JSON.stringify(data);
					window.sessionStorage.setItem("baseData", baseData);
					console.log(data.userName);
					renderTemp(data);
					reBack = false;
				} else {
					Toast("基本信息获取有错哦");
					reBack = true;
				}
			},
			complete: function() {
				if (reBack) {
					window.location.href = "../com.midea.login/index.html";
				} else {
					console.log("moddule checking...");
					ajaxloader.hide();
					cordova.exec(function(data) {}, function(error) {}, "CubeModuleOperator", "sync", []);
				}

			}
		});

	}

	//查找该用户是否同意协议接口
	function findLogService() {
		var logininfo = window.localStorage.getItem("logininfo"),
			loginfo = JSON.parse(logininfo),
			url = OpenAPI.findLogService + loginfo.username;
		$.ajax({
			url: url,
			dataType: "json",
			beforeSend: function(error) {},
			error: function(error) {},
			success: function(data) {
				console.log("findLogService:  " + JSON.stringify(data));

				// initagreement();
				// $(".agreepic")[0].src = selImg;
				// $(".agreement").attr("data-value", "true");
				// $(".confirmBtn").removeClass("greyf");

				// $(".dailog").attr("style", "height:" + 800 + "px !important;");

				if (!data.id) {
					initagreement();
					$(".agreepic")[0].src = selImg;
					$(".agreement").attr("data-value", "true");
					$(".confirmBtn").removeClass("greyf");
				}
			},
			complete: function() {}
		});
	}
	// 设置同意协议接口
	function legalLogService() {
		var logininfo = window.localStorage.getItem("logininfo"),
			loginfo = JSON.parse(logininfo),
			url = OpenAPI.legalLogService;
		console.log(baseData);
		if (typeof baseData == "string") {
			baseData = JSON.parse(baseData);
		}
		var baseD = baseData.resultForm;
		var options = {
			"idCard": loginfo.username,
			"name": baseD.name,
			"depart": baseD.unitShortName,
			"telephone": baseD.tele,
			"workNumber": baseD.code
		};
		console.info(options);
		$.ajax({
			url: url,
			data: JSON.stringify(options),
			contentType: "Application/json",
			type: "POST",
			beforeSend: function(error) {},
			error: function(error) {},
			success: function(data) {},
			complete: function() {}
		});
	}
	// 记录日志接口
	function loginLogService() {
		var logininfo = window.localStorage.getItem("logininfo"),
			loginfo = JSON.parse(logininfo),
			url = OpenAPI.loginLogService,
			options = {
				idCard: loginfo.username,
				depart: baseData.resultForm.unitShortName
			};
		$.ajax({
			url: url,
			data: JSON.stringify(options),
			contentType: "Application/json",
			dataType: "json",
			type: "POST",
			beforeSend: function(error) {},
			error: function(error) {},
			success: function(data) {},
			complete: function() {}
		});
	}
	// 初始化的时候日志处理和判断是否同意协议方法
	findLogService();
	loginLogService();
});