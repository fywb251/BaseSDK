define(['zepto'], function($) {
    // var ip = "https://dove-rest-dev.hnair.net:9600";
    //var ip = "https://dove-rest-dev.hnair.net:9601";
    // var ip = "https://dove-rest.hnair.net";
    // var isLocal = false;
    // var ip = "http://10.16.64.24:9080";
    // var ip = "http://10.16.64.24:9080";
    // var ip = "http://ehrtest.midea.com.cn:9080";
    var ip = "http://apps.midea.com/";
    var iputl = ip + "bsl-web/midea/ehr/";
    // var ip = "http://10.32.1.66:8080/bsl-web/midea/ehr/";
    var OpenAPI = {
        "isLocal": false,
        "dataType": "JSON",
        "pageSize": 10,
        "access_token": iputl + "/action/openapi/token",
        "clear_notice": iputl + "/action/openapi/clear_notice",
        // 公共接口
        // "baseApi" : iputl + "/midea_2/personalinfo/dataservices.do&jsonpcallback=?",
        "baseApi": iputl,
        "loginUrl": ip + "system/api/system/mobile/accounts/login",
        "resetUrl": ip + "sso/api/loginService/resetPassword",
        "mipBaseApi": ip + "bsl-web/midea/mip/redirect",
        //反馈信息类型
        "url_feedback_type": ip + "bsl-web/midea/mip/getCategories",
        //MIP测试地址
        "mipBaseUrl": ip + "bsl-web/midea/mip/redirect",
        //小类的IP
        "mipSmallId": ip + "bsl-web/midea/mip/getCategories2",
        // 创建投诉咨询建议
        "createIssd": ip + "bsl-web/midea/mip/createCategories",
        "recordlog": ip + "bsl-web/interfaceLog/records",
        "passRset": ip + "sso/api/loginService/updatePassword",
        "checkVersion": ip + "bsl-web/downloads/updateVerson",
        // 查找该用户是否同意协议接口
        "findLogService": ip + "sso/api/legalLogService/findOne/",
        // 设置同意协议接口
        "legalLogService": ip + "sso/api/legalLogService/save",
        // 记录日志接口
        "loginLogService": ip + "sso/api/loginLogService/save",

    };
    return OpenAPI;
});