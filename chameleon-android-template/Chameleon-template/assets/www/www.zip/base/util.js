define(['zepto', "../base/openapi", "../base/date"],
	function($, OpenAPI, DateUtil) {

		var Util = {
			goback: function(that) {
				window.location.href = "../com.midea.tools/index.html";
			},
			isIosFlatform: function() {
				if (navigator.userAgent.match(/(iPad|iPhone)/)) {
					return true;
				} else {
					return false;
				}
			},

			isAndroidFlatform: function() {
				if (navigator.userAgent.match(/(Android)/)) {
					return true;
				} else {
					return false;
				}
			},
			isMobile: function() {
				if (Util.isIosFlatform() || Util.isAndroidFlatform()) {
					return true;
				} else {
					return false;
				}
			},
			isNull: function(data) {
				var def = true,
					tostr = Object.prototype.toString;
				// 如果def还是为true则判断data是否undefined
				if (typeof data == "boolean") {
					if (!data) {
						def = false;
					}
				}

				if (typeof data == "string") {
					data = data.trim();
					if (data.length !== 0) {
						def = false;
					}
				}
				if (typeof data == "object") {
					// 如果是对象并且是null不用管
					// 如果是对象并且是array判断长度
					if (Array.isArray && Array.isArray(data) || tostr.call(data) == "[object Array]") {
						if (data.length > 0) {
							def = false;
						}
						// 如果是对象并且是object
					} else if (tostr.call(data) == "[object Object]") {
						if (Object.keys && Object.keys(data).length > 0) {
							def = false;
						} else {
							var sum = 0;
							for (var i in data) {
								sum++;
							}
							if (sum > 0) {
								def = false;
							}
						}

					}
				}
				return def;
			},
			/*list组件*/
			loadList: function(me, listName, url, params, isLoadFromServer, successCallback, errorCallback) {
				var list = me.component(listName); // 获取组件
				list.config.url = url;
				list.config.pageSize = params.pageSize;
				list.config.successCallback = successCallback;
				list.config.errorCallback = errorCallback;
				params.client_id = OpenAPI.client_id;
				if (isLoadFromServer) {
					list.setRequestParams(params);
				} else {
					// list.setRequestParams(params, false);
					if (list.isExistStoreData(listName)) {
						list.loadListByStoreData(url, params);
					} else {
						list.setRequestParams(params);
					}
				}
			},
			Ajax: function(urls, datas, successCallback, errorCallback, completeCallback, isLoaderControlByClient) {
				var me = this;
				var loader,
					meUrls = urls,
					isCanceled = false,
					locationpath,
					locationpath1;
				$.ajax({
					timeout: 10 * 1000,
					url: urls,
					data: datas,
					dataType: "json",
					beforeSend: function(xhr, settings) {

						//ajax请求前次数加1
						locationpath = window.location.hash;
						if (isLoaderControlByClient) {} else {
							loader = new Piece.Loader({
								autoshow: true, //是否初始化时就弹出加载控件
								target: 'body' //页面目标组件表识
							});
							/**
							 *点击loader cancel时阻断数据请求处理的进一步进行
							 *特殊场景描述：如果页面有嵌套ajax，这个会绑定2次所以绑定之前先进行解绑
							 *但是解绑后会将piece框架中的关闭loader事件也解除，所以在这里绑定事件中也
							 *加上loader.hide();
							 */
							$(".cube-loader-cancel").unbind("click").bind("click", function() {
								loader.hide();
								isCanceled = true;
							});
						}
					},
					success: function(data, textStatus, jqXHR) {
						locationpath1 = window.location.hash;
						console.log("success");
						if (!me.isNull(data) && typeof data == "string") {
							data = JSON.parse(data);
						}
						if (!isCanceled) {
							//回调给html页面处理data
							if (successCallback !== null && successCallback !== undefined) {
								// 如果页面没有跳转则执行回调函数
								if (isLoaderControlByClient) {
									successCallback(data, textStatus, jqXHR);
								} else {
									if (locationpath === locationpath1) {
										successCallback(data, textStatus, jqXHR);
									}
								}

							}
						}
					},
					error: function(e, xhr, type) {
						if (!isCanceled) {
							me.recordlog(e);
							if (errorCallback !== null && errorCallback !== undefined) {
								errorCallback(e, xhr, type);
							}
						}
					},
					complete: function(xhr, status) {
						if (status == 'timeout') { //超时,status还有success,error等值的情况
							new Piece.Toast("网络请求超时");　　　　
							loader.hide();　
							return;　　　　　　　　
						}
						
						console.log("complete");
						var data = {};
						if (!isCanceled) {
							/*页面数据加载*/
							if (isLoaderControlByClient) {} else {
								loader.hide();
							}
						}
						if (!me.isNull(completeCallback)) {
							if (isLoaderControlByClient) {
								completeCallback(xhr, status, data);
							} else {
								if (locationpath === locationpath1) {
									completeCallback(xhr, status, data);
								}
							}
						}

					}
				});
			},
			recordlog: function(error) {
				var me = this;
				var res = {
					"code": "没有状态返回",
					"message": "没有错误信息返回"
				};
				var username = window.localStorage.getItem("username");
				if (error.response) {
					res = error.response;
					console.log(typeof res);
					if (typeof res == "string") {
						res = JSON.parse(res);
					}
				}
				var datapram = {
					"errorCode": res.code,
					"errorMessage": res.message,
					"operate": username
				};
				me.ajaxPost(OpenAPI.recordlog,
					datapram,
					function() {
						console.log("before");
					},
					function() {
						console.log("success");
					},
					function() {
						console.log("complete");
					}
				);
			},
			ajaxPost: function(url, param, beforeFun, succFun, errorFun, compFun) {
				var me = this;
				console.log(param);
				$.ajax({
					url: url,
					type: "POST",
					data: JSON.stringify(param),
					contentType: "application/json",
					beforeSend: function(xhr) {
						if (beforeFun !== null && beforeFun !== undefined) {
							beforeFun(xhr);
						}
					},
					success: function(data, textStatus, jqXHR) {
						//回调给html页面处理data
						if (succFun !== null && succFun !== undefined) {
							// 如果页面没有跳转则执行回调函数
							succFun(data, textStatus, jqXHR);
						}
					},
					error: function(e, xhr, type) {
						if (errorFun !== null && errorFun !== undefined) {
							errorFun(e, xhr, type);
						}
					},
					complete: function(xhr, status, data) {
						if (compFun !== null && compFun !== undefined) {
							compFun(xhr, status, data);
						}
					}
				});
			}
		};

		return Util;
	});